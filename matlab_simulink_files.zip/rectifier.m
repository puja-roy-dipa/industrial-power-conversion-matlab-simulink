
%% --- Input & Output Voltage Signals ---
V_source = out.vs_rect.signals.values;   % Source voltage waveform
v_out = out.v_rect.signals.values;       % Rectified output voltage waveform

%% --- RMS and Average Voltage Calculations ---
V_rms = rms(V_source);
disp(['RMS Input Voltage (Vrms): ', num2str(V_rms, '%.4f'), ' V']);

Vm = V_rms * sqrt(2);
disp(['Peak Input Voltage (Vm): ', num2str(Vm, '%.4f'), ' V']);

% --- Average DC output voltage (theoretical and simulated) ---
V_dc_theoretical = (2 * Vm) / pi;  % For full-wave rectifier
V_dc_measured = mean(v_out);

disp(['Average Output Voltage (Vdc, theoretical): ', num2str(V_dc_theoretical, '%.4f'), ' V']);
disp(['Average Output Voltage (Vdc, measured): ', num2str(V_dc_measured, '%.4f'), ' V']);

%% --- Ripple Factor Calculation ---
V_rms_out = rms(v_out);
ripple_factor = sqrt((V_rms_out / V_dc_measured)^2 - 1) * 100;
disp(['Ripple Factor: ', num2str(ripple_factor, '%.2f'), ' %']);

%% THD
v_out = out.v_rect.signals.values;
V_rms_total = rms(v_out);

Vm = max(v_out);             % Approx. peak value from waveform
V1 = Vm / 2;                 % Fundamental RMS for full-wave

THD = sqrt((V_rms_total / V1)^2 - 1) * 100;
disp(['THD (no FFT) = ', num2str(THD, '%.2f'), ' %']);

%% --- Overall Efficiency Calculation ---
% Efficiency = (DC output power) / (AC input power) * 100
I_out = out.i_rect.signals.values;   % Output current waveform (if available)
I_in = out.is_rect.signals.values;   % Output current waveform (if available)
I_rms = rms(I_in);
if exist('I_out', 'var')
    P_dc = mean(v_out .* I_out);     % Average DC output power
    P_ac = mean(V_rms .* I_rms);  % Input power from source
    efficiency = (P_dc / P_ac) * 100;
    disp(['Overall Efficiency: ', num2str(efficiency, '%.2f'), ' %']);
else
    disp('Output current not found. Efficiency calculation skipped.');
end

%% --- Summary ---
disp('---------------------------------------------');
disp('Performance Parameters Summary:');
disp(['Vdc (avg output voltage)     = ', num2str(V_dc_measured, '%.4f'), ' V']);
disp(['Ripple Factor                = ', num2str(ripple_factor, '%.2f'), ' %']);
disp(['Total Harmonic Distortion    = ', num2str(THD, '%.2f'), ' %']);
if exist('efficiency', 'var')
    disp(['Overall Efficiency           = ', num2str(efficiency, '%.2f'), ' %']);
end
disp('---------------------------------------------');

